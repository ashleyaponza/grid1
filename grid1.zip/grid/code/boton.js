const hazAlgo = document.getElementById("boton1");
const hazAlgo2= document.getElementById("boton2");
const hazAlgo3= document.getElementById("boton3");


hazAlgo.onclick = function () {
 document.body.style.backgroundColor = "#d666ffff";
 parrafo1.style.color="rgb(23, 236, 172)";
 document.title="Este es mi nombre";
}

hazAlgo2.onclick = function () {
 document.body.style.backgroundColor = "#669cffff";
 parrafo2.style.Color="#5d91e5";
}

hazAlgo3.onclick = function () {
 document.body.style.backgroundColor = "#ff66faff";
 parrafo3.style.Color="#a151da";
 document.body.backgroundColor="#f3bde3";
}
